//
//  PlaylistModel.swift
//  IN_SOPT_Welaaa
//
//  Created by 류희재 on 2022/11/17.
//


import Foundation
import UIKit

struct RecommandAudioBookModel {
    let bookImage : String
    let title : String
    let author : String
    
    
}

var recommandAudioBookDummyData: [RecommandAudioBookModel] = [
    RecommandAudioBookModel(bookImage: "달러구트", title: "거짓말", author: "거짓말"),
    RecommandAudioBookModel(bookImage: "달러구트", title: "거짓말", author: "거짓말"),
    RecommandAudioBookModel(bookImage: "달러구트", title: "거짓말", author: "거짓말")
]
