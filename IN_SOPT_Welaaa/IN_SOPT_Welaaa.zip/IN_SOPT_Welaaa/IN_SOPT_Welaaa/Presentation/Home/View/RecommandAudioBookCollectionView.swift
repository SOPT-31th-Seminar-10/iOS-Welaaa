////
////  RecommandAudioBookCollectionView.swift
////  IN_SOPT_Welaaa
////
////  Created by 류희재 on 2022/11/17.
////
//
//import UIKit
//
//import SnapKit
//import Then
//
//final class RecommandAudioBookCollectionView: BaseView {
//    
//    static let identifier = "RecommandAudioBookCollectionCell"
//    
//    lazy var recommandAudioBookCollectionView = UICollectionView(frame: .zero, collectionViewLayout: UICollectionViewFlowLayout()).then {
//        let layout = UICollectionViewFlowLayout()
//        layout.scrollDirection = .horizontal
//        
//        $0.translatesAutoresizingMaskIntoConstraints = false
//        $0.isScrollEnabled = true
//        $0.backgroundColor = .white
//        $0.showsHorizontalScrollIndicator = false
//        $0.collectionViewLayout = layout
//        $0.delegate = self
//        $0.dataSource = self
//        
//        $0.register(RecommandAudioBookCollectionViewCell.self,
//                    forCellWithReuseIdentifier: RecommandAudioBookCollectionViewCell.identifier)
//    }
//    
//    override func setupView() {
//        addSubview(recommandAudioBookCollectionView)
//    }
//    
//    override func setupConstraints() {
//        recommandAudioBookCollectionView.snp.makeConstraints{
//            $0.edges.equalToSuperview()
//        }
//    }
//    
//    func registerCollectionView() {
//        recommandAudioBookCollectionView.register(RecommandAudioBookCollectionViewCell.self, forCellWithReuseIdentifier: RecommandAudioBookCollectionViewCell.identifier )
//    }
//}
//
//
