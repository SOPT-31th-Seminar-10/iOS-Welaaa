////
////  HomeTableView.swift
////  IN_SOPT_Welaaa
////
////  Created by 류희재 on 2022/11/18.
////
//
//import UIKit
//
//import SnapKit
//import Then
//
//final class HomeTableView: BaseView {
//    
//    
//    lazy var homeTableView = UITableView(frame: .zero, style: .grouped).then{
//        $0.backgroundColor = .white
//        $0.translatesAutoresizingMaskIntoConstraints = false
//        $0.isScrollEnabled = true
//        $0.showsVerticalScrollIndicator = false
//        //$0.delegate = self
//        //$0.dataSource = self
//    }
//        func registerCollectionView() {
////            
//    
//}
//
////extension HomeTableView: UITableViewDataSource {
////    func numberOfSections(in tableView: UITableView) -> Int {
////            return 2
////        }
////}
