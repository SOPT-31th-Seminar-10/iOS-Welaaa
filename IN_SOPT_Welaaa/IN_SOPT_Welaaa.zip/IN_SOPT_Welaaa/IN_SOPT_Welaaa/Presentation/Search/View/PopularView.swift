//
//  PopularView.swift
//  IN_SOPT_Welaaa
//
//  Created by 김승찬 on 2022/11/12.
//

import UIKit

import SnapKit
import Then

final class PopularView: BaseView {
    
   
    
    override func setupView() {
      
      
    }
    
    override func setupConstraints() {
        
      
    }
}
